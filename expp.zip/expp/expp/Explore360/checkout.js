// Load cart from localStorage and sync to PHP session
window.onload = function () {
    syncCartWithSession();
    displayCart();
};

// Function to sync localStorage cart with PHP session via AJAX
function syncCartWithSession() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Send cart data to PHP if it exists
    if (cart.length > 0) {
        fetch('sync_cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cart })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log("Cart synced with PHP session.");
                displayCart();
            }
        })
        .catch(error => console.error("Error syncing cart:", error));
    }
}

// Function to display the cart items on checkout.php
function displayCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    let total = 0;

    // Update the HTML display for each item in the cart
    const cartItemsDiv = document.getElementById('cart-items');
    cartItemsDiv.innerHTML = ''; // Clear previous items

    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('gear-item');
        itemDiv.innerHTML = `
            <h3>${item.name}</h3>
            <p>Price: R${item.price}</p>
        `;
        cartItemsDiv.appendChild(itemDiv);
        total += item.price;
    });

    // Display the total price
    document.getElementById('total-price').innerText = `Total Price: R${total}`;
}
