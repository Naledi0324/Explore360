<?php
require_once 'Database.php'; 

class User
{
    private $db;

    public function __construct($mysqli)
    {
        $this->db = $mysqli;
    }

    
    public function register($fullname, $email, $password)
    {
        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Prepare and bind statement to prevent SQL injection
        $stmt = $this->db->prepare("INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fullname, $email, $hashedPassword);

        // Execute and check for success
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    
    public function login($email, $password)
    {
        // Prepare the statement to prevent SQL injection
        $stmt = $this->db->prepare("SELECT id, fullname, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a user was found
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verify the password
            if (password_verify($password, $user['password'])) {
                // Start session and set user information
                session_start();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['fullname'];
                return true;
            }
        }

        // If no match, return false
        return false;
    }

    
    public function isLoggedIn()
    {
        return isset($_SESSION['user_id']);
    }

    
    public function logout()
    {
        session_start();
        session_unset();
        session_destroy();
    }
}
?>
