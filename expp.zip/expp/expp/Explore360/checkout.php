<?php
session_start();

// Redirect to address page if no address is entered
if (!isset($_SESSION['address'])) {
    header('Location: address.php');
    exit;
}

// Ensure the cart session is available
$cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Calculate total price of the cart items
$totalPrice = 0;
foreach ($cartItems as $item) {
    $totalPrice += $item['price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" style="text-decoration: none; color: white" title="Homepage">
                <img src="img/logom.jpg" alt="Explore360 Logo" class="logo-img" width="90" height="90" />
            </a>
        </div>
        <a href="cart.html" title="Back to cart" class="cart-icon">🛒</a>
    </header>

    <h1>Checkout</h1>

    <!-- Shipping Address Section -->
    <h2>Shipping Address</h2>
    <div class="address">
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['address']['fname'] . " " . $_SESSION['address']['Lname']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($_SESSION['address']['phone']); ?></p>
        <p><strong>Street Address:</strong> <?php echo htmlspecialchars($_SESSION['address']['stradd']); ?>, <?php echo htmlspecialchars($_SESSION['address']['building']); ?></p>
        <p><strong>Suburb:</strong> <?php echo htmlspecialchars($_SESSION['address']['Suburb']); ?></p>
        <p><strong>City:</strong> <?php echo htmlspecialchars($_SESSION['address']['city']); ?></p>
        <p><strong>State/Province:</strong> <?php echo htmlspecialchars($_SESSION['address']['state']); ?></p>
        <p><strong>Zip Code:</strong> <?php echo htmlspecialchars($_SESSION['address']['zip']); ?></p>
        <p><strong>National ID/Passport Number:</strong> <?php echo htmlspecialchars($_SESSION['address']['customclearance']); ?></p>
    </div>

    <!-- Cart Items Section -->
    <h2>Items in Your Cart</h2>
    <div id="cart-items" class="gear-items">
        <?php
        if (empty($cartItems)) {
            echo "<p>Your cart is empty.</p>";
        } else {
            foreach ($cartItems as $item) {
                echo "<div class='gear-item'>
                        <h3>" . htmlspecialchars($item['name']) . "</h3>
                        <p>Price: R" . htmlspecialchars($item['price']) . "</p>
                    </div>";
            }
        }
        ?>
    </div>

    <!-- Total Price Section -->
    <h3 id="total-price">Total Price: R<?php echo htmlspecialchars($totalPrice); ?></h3>

    <!-- Form for submitting the order -->
    <form action="order_confirmation.php" method="post">
        <button type="submit" class="submitorder-btn">Submit Order</button>
    </form>

    <footer>
        <p>&copy; 2023 Explore360. All rights reserved.</p>
        <div class="contact-info">
            <p>Address: 123 Adventure Lane, Johannesburg, South Africa</p>
            <p>Phone: +27 10 123 4567</p>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a>
            <a href="#">Instagram</a>
            <a href="#">Twitter</a>
        </div>
    </footer>

    <!-- Include checkout.js if needed -->
    <script src="checkout.js"></script>
</body>
</html>


