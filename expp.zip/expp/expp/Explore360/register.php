<?php
session_start();
require_once 'Database.php';
require_once 'user.php';

$user = new User($mysqli);

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form inputs
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $repassword = trim($_POST['repassword']);

    // Validate form fields
    if (empty($fullname) || empty($email) || empty($password) || empty($repassword)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password !== $repassword) {
        $error = "Passwords do not match.";
    } else {
        // Attempt to register the user
        if ($user->register($fullname, $email, $password)) {
            // Redirect to login page if registration is successful
            header("Location: login.html");
            exit();
        } else {
            // Set an error message if registration fails
            $error = "Registration failed. Email might already be registered.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Signup</title>
    <link rel="stylesheet" href="style.css" />
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
        crossorigin="anonymous"
    />
    <link rel="icon" href="img/123.ico" type="image/x-icon" />
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" style="text-decoration: none; color: white" title="Homepage">
                <img src="img/logom.jpg" alt="Explore360 Logo" class="logo-img" width="90" height="90" />
            </a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
            </ul>
        </nav>
    </header>

    <div class="register">
        <div class="sign-container">
            <h3 class="h22">Sign Up</h3>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="fullname">Full Name:</label><br />
                    <input
                        type="text"
                        name="fullname"
                        class="form-control"
                        placeholder="Enter your fullname"
                        required
                    />
                </div>
                <br />
                <div class="form-group">
                    <label for="email">Email:</label><br />
                    <input
                        type="email"
                        name="email"
                        class="form-control"
                        placeholder="Enter your email"
                        required
                    />
                </div>
                <br />
                <div class="form-group">
                    <label for="password">Password:</label><br />
                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        placeholder="Enter your password"
                        required
                    />
                </div>
                <br />
                <div class="form-group">
                    <label for="repassword">Password (Confirm):</label><br />
                    <input
                        type="password"
                        name="repassword"
                        class="form-control"
                        placeholder="Confirm your password"
                        required
                    />
                </div>
                <br />
                <div class="form-gp">
                    <input
                        type="submit"
                        value="Sign Up"
                        class="btn btn-primary form-control"
                        name="submit"
                    />
                </div>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2023 Explore360. All rights reserved.</p>

        <div class="contact-info">
        <p>Address: 123 Adventure Lane, Johannesburg, South Africa</p>
        <p>Phone: +27 10 123 4567</p>
    </div>
    
        <div class="social-media">
          <a href="#">Facebook</a>
          <a href="#">Instagram</a>
          <a href="#">Twitter</a>
        </div>
      </footer>

    <!-- Link to the JavaScript file -->
    <script src="app.js"></script>
</body>
</html>
