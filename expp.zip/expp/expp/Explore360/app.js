// Smooth Scroll, Form Validation, and Search Functionality
document.addEventListener('DOMContentLoaded', function() {
  
  // ==========================
  // Form Validation
  // ==========================
  const forms = document.querySelectorAll('form');

  forms.forEach(form => {
    form.addEventListener('submit', function(event) {
      const email = form.querySelector('input[name="email"]');
      const password = form.querySelector('input[name="password"]');
      const fullname = form.querySelector('input[name="fullname"]');
      const repassword = form.querySelector('input[name="repassword"]');
      
      // Login form validation
      if (form.id === 'login-form') {
        if (email && password && (email.value.trim() === '' || password.value.trim() === '')) {
          event.preventDefault();
          alert('Please fill in both email and password fields.');
        } else if (email && !validateEmail(email.value)) {
          event.preventDefault();
          alert('Please enter a valid email address.');
        }
      }

      // Signup form validation
      if (form.id === 'signup-form') {
        if (fullname && email && password && repassword && 
          (fullname.value.trim() === '' || email.value.trim() === '' || password.value.trim() === '' || repassword.value.trim() === '')) {
          event.preventDefault();
          alert('Please fill in all fields.');
        } else if (email && !validateEmail(email.value)) {
          event.preventDefault();
          alert('Please enter a valid email address.');
        } else if (password && repassword && password.value !== repassword.value) {
          event.preventDefault();
          alert('Passwords do not match.');
        }
      }
    });
  });

  function validateEmail(email) {
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return regex.test(email);
  }

  // ==========================
  // Search Functionality
  // ==========================
  document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('input', filterItems);
    }
  
    function filterItems() {
      const searchQuery = searchInput.value.toLowerCase();
      const items = document.querySelectorAll('.gear-item');
      let hasVisibleItems = false;
  
      items.forEach(item => {
        const itemName = item.getAttribute('data-name').toLowerCase();
  
        if (itemName.includes(searchQuery)) {
          item.style.display = 'block';
          hasVisibleItems = true;
        } else {
          item.style.display = 'none';
        }
      });
  
      document.getElementById('noResultsMessage').style.display = hasVisibleItems ? 'none' : 'block';
    }
  });

  // ==========================
  // Smooth Scroll
  // ==========================
  const smoothScrollLinks = document.querySelectorAll('a[href^="#"]');
  smoothScrollLinks.forEach(link => {
    link.addEventListener('click', function(event) {
      event.preventDefault();
      const targetId = link.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 100,
          behavior: 'smooth'
        });
      }
    });
  });

});


  
  