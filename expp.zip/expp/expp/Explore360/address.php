<?php
session_start();

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Store the address data in session
    $_SESSION['address'] = [
        'place' => $_POST['place'],
        'fname' => $_POST['fname'],
        'Lname' => $_POST['Lname'],
        'phone' => $_POST['phone'],
        'stradd' => $_POST['stradd'],
        'building' => $_POST['building'],
        'Suburb' => $_POST['Suburb'],
        'city' => $_POST['city'],
        'state' => $_POST['state'],
        'zip' => $_POST['zip'],
        'customclearance' => $_POST['customclearance'],
    ];
    
    // Redirect to checkout page after saving address
    header('Location: checkout.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your Address</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="icon" href="img/123.ico" type="image/x-icon" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
  </head>
  <body>
    <header>
      <div class="logo">
        <a href="index.php" style="text-decoration: none; color: white" title="Homepage">
          <img src="img/logom.jpg" alt="Explore360 Logo" class="logo-img" width="90" height="90" />
        </a>
      </div>
      <nav>
        <ul class="nav-menu">
          <li><a href="login.php" title="Login to your account"><span class="material-icons">login</span></a></li>
        </ul>
      </nav>
    </header>

    <h2>Add Your Shipping Address</h2>
    <form action="address.php" method="post" id="checkout-form">
      <!-- Address fields -->
      <div class="userinfo">
        <label for="place">Country/Region </label><br />
        <input type="text" id="place" name="place" required />
      </div><br />
      <div class="userinfo">
        <label for="fname">First Name </label><br />
        <input type="text" id="fname" name="fname" required />
      </div><br />
      <div class="userinfo">
        <label for="Lname">Last Name </label><br />
        <input type="text" id="Lname" name="Lname" required />
      </div><br />
      <div class="userinfo">
        <label for="phone">Phone Number </label><br />
        <input type="tel" id="phone" name="phone" required />
      </div><br />
      <div class="userinfo">
        <label for="stradd">Street Address </label><br />
        <input type="text" id="stradd" name="stradd" required />
      </div><br />
      <div class="userinfo">
        <label for="building">Complex/Building (optional)</label><br />
        <input type="text" id="building" name="building" />
      </div><br />
      <div class="userinfo">
        <label for="Suburb">Suburb </label><br />
        <input type="text" id="Suburb" name="Suburb" required />
      </div><br />
      <div class="userinfo">
        <label for="city">City </label><br />
        <input type="text" id="city" name="city" required />
      </div><br />
      <div class="userinfo">
        <label for="state">State/Province </label><br />
        <input type="text" id="state" name="state" required />
      </div><br />
      <div class="userinfo">
        <label for="zip">Zip Code </label><br />
        <input type="text" id="zip" name="zip" required />
      </div><br />
      <div class="userinfo">
        <label for="customclearance">National ID/ Passport number </label><br />
        <input type="text" id="customclearance" name="customclearance" required />
      </div><br />
      <button type="submit" class="checkout-btn">Save Address</button>
    </form>

    <footer>
      <p>&copy; 2023 Explore360. All rights reserved.</p>
      <div class="contact-info">
        <p>Address: 123 Adventure Lane, Johannesburg, South Africa</p>
        <p>Phone: +27 10 123 4567</p>
      </div>
      <div class="social-media">
        <a href="#">Facebook</a>
        <a href="#">Instagram</a>
        <a href="#">Twitter</a>
      </div>
    </footer>
  </body>
</html>

