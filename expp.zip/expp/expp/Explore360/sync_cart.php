<?php
session_start();

// Retrieve cart data sent from JavaScript
$cartData = json_decode(file_get_contents("php://input"), true);

if (isset($cartData['cart'])) {
    $_SESSION['cart'] = $cartData['cart'];
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}

