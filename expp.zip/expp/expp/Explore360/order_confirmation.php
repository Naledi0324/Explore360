<?php
session_start();

// Redirect to cart.html if there are no items in the cart
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.html');
    exit;
}

// Redirect to address.php if the address is missing
if (!isset($_SESSION['address'])) {
    header('Location: address.php');
    exit;
}

$cartItems = $_SESSION['cart'];
$address = $_SESSION['address'];

// Calculate the total price
$totalPrice = 0;
foreach ($cartItems as $item) {
    $totalPrice += $item['price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" style="text-decoration: none; color: white" title="Homepage">
                <img src="img/logom.jpg" alt="Explore360 Logo" class="logo-img" width="90" height="90" />
            </a>
        </div>
        <a href="cart.html" title="Back to cart" class="cart-icon">🛒</a>
    </header>

    <h1>Order Confirmation</h1>

    <h2>Shipping Address</h2>
    <div class="address">
        <p><strong>Name:</strong> <?php echo htmlspecialchars($address['fname'] . " " . $address['Lname']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($address['phone']); ?></p>
        <p><strong>Street Address:</strong> <?php echo htmlspecialchars($address['stradd']); ?>, <?php echo htmlspecialchars($address['building']); ?></p>
        <p><strong>Suburb:</strong> <?php echo htmlspecialchars($address['Suburb']); ?></p>
        <p><strong>City:</strong> <?php echo htmlspecialchars($address['city']); ?></p>
        <p><strong>State/Province:</strong> <?php echo htmlspecialchars($address['state']); ?></p>
        <p><strong>Zip Code:</strong> <?php echo htmlspecialchars($address['zip']); ?></p>
        <p><strong>National ID/Passport Number:</strong> <?php echo htmlspecialchars($address['customclearance']); ?></p>
    </div>

    <h2>Order Summary</h2>
    <div id="order-items">
        <?php
        foreach ($cartItems as $item) {
            echo "<div class='gear-item'>
                    <h3>" . htmlspecialchars($item['name']) . "</h3>
                    <p>Price: R" . htmlspecialchars($item['price']) . "</p>
                </div>";
        }
        ?>
    </div>

    <h3>Total Price: R<?php echo htmlspecialchars($totalPrice); ?></h3>

    <p>Thank you for your order! We will process it soon.</p>

    <footer>
        <p>&copy; 2023 Explore360. All rights reserved.</p>
        <div class="contact-info">
            <p>Address: 123 Adventure Lane, Johannesburg, South Africa</p>
            <p>Phone: +27 10 123 4567</p>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a>
            <a href="#">Instagram</a>
            <a href="#">Twitter</a>
        </div>
    </footer>
</body>
</html>

